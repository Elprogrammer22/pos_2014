<?php
include('./config/database.php');

// Fetch products from the database
$product_query = mysqli_query($conn, "SELECT * FROM pos_product");
?>

<table class="table">
    <thead>
        <tr>
            <th>No.</th>
            <th>Product Name</th>
            <th>Product Code</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $counter = 1;
        while ($product = mysqli_fetch_assoc($product_query)) {
            echo "<tr>";
            echo "<td>{$counter}</td>";
            echo "<td>{$product['P_name']}</td>";
            echo "<td>{$product['P_code']}</td>";
            echo "</tr>";
            $counter++;
        }
        ?>
    </tbody>
</table>
