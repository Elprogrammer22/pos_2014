<?php
include('./config/database.php');

// Process form submission
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $conpass = $_POST['conpass'];
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $errors = [];

    // Validate input fields
    if (empty($name) || empty($email) || empty($username) || empty($password) || empty($conpass)) {
        $errors[] = "All fields are required.";
    }

    if ($password !== $conpass) {
        $errors[] = "Passwords do not match.";
    }

    // Check if username already exists
    $sql = "SELECT * FROM pos_accnt WHERE a_username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $rowCount = mysqli_num_rows($result);
    mysqli_stmt_close($stmt);

    if ($rowCount > 0) {
        $errors[] = "Username already exists.";
    }

    // Display errors if any, otherwise register user
    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {
        $sql = "INSERT INTO pos_accnt (a_name, a_email, a_username, a_password) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $username, $passwordHash);
            mysqli_stmt_execute($stmt);
            echo "<div class='alert alert-success'>You are successfully registered.</div>";
            mysqli_stmt_close($stmt);
        } else {
            die("Something went wrong.");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en" ng-app="registrationApp">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>POS | Registration</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icon-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Font -->
  <link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <!-- AngularJS -->
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
  <style>
    body {
      background: linear-gradient(to right, #17a2b8, #FFA500) 100%;
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      background-image: url('https://cdn.jsdelivr.net/gh/subtlepatterns/Free/SubtlePatterns/white_carbon.png');
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      max-width: 400px;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
      background-color: #fff;
      animation: fade-in 0.5s ease-out;
    }
    @keyframes fade-in {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    .form-control {
      border-radius: 25px;
    }
    .btn-primary {
      width: 100%;
      border-radius: 25px;
      background-color: #FFA500;
      border: none;
      transition: all 0.3s ease;
    }
    .btn-primary:hover {
      background-color: #FF8C00;
    }
    .alert {
      border-radius: 10px;
    }
  </style>
</head>
<body ng-controller="RegistrationController">
  <div class="container">
<<<<<<< HEAD
    <h4 class="text-center mb-4">Registration</h4>
    <form name="registrationForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <div class="mb-3">
        <input type="text" class="form-control" name="name" ng-model="user.name" placeholder="Name" required>
=======
  <h4 class="text-center mt-2 h-font">Registration</h4>

   
<?php
if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $conpass = $_POST['conpass'];
  $passworddef= password_hash($password, PASSWORD_DEFAULT);
  $error = array();
  if (empty($name) OR empty($email) OR empty($username) OR empty($password) OR empty($conpass) ) {
   array_push($error,"All Fields are Required");
  }

  if ($password!==$conpass) {
    array_push($error,"Password does not match");
  }
  require_once('./config/database.php');
  $sql="SELECT * FROM pos_accnt WHERE a_username = '$username'";
  $result =mysqli_query($conn,$sql);
  $rowCount= mysqli_num_rows($result);
  
  if ($rowCount>0) {
    array_push($error,"Username Already exists!");
  }
  
  if (count($error)>0) {
    foreach ($error as $errors) {
      echo "<div class='alert alert-danger'>$errors</div>";
    }
  } else {
   $sql = "INSERT INTO pos_accnt (a_name, a_email, a_username, a_password) VALUES (?, ?, ?, ?)";
   $stmt = mysqli_stmt_init($conn);
   $preparestmt = mysqli_stmt_prepare($stmt, $sql);

   if ($preparestmt) {
    mysqli_stmt_bind_param($stmt,"ssss", $name, $email, $username, $passworddef );
    mysqli_stmt_execute($stmt);
    echo "<div class='alert alert-success'>You are successfully Registered.</div>";
   } else{
    die("Something went wrong");
   }

  }
}

?>


  <form action="index.php" method="post">
    
    <div class="row mb-3">
      <div class="col">
       <label class="form-label">Name:</label>
       <input  type="text" class="form-control" name="name">
>>>>>>> 1fafdadd82b62ee522fcdfd0ca4ed667bd7f4679
      </div>
      <div class="mb-3">
        <input type="email" class="form-control" name="email" ng-model="user.email" placeholder="Email" required>
      </div>
      <div class="mb-3">
        <input type="text" class="form-control" name="username" ng-model="user.username" placeholder="Username" required>
      </div>
      <div class="mb-3">
        <input type="password" class="form-control" name="password" ng-model="user.password" placeholder="Password" required>
      </div>
      <div class="mb-3">
        <input type="password" class="form-control" name="conpass" ng-model="user.confirmPassword" placeholder="Confirm Password" required>
      </div>
      <button type="submit" class="btn btn-primary mb-3" name="submit" ng-disabled="registrationForm.$invalid">Register</button>
      <p class="text-center mb-0">Already have an account? <a href="login.php">Login Here</a></p>
    </form>
    <div class="alert" ng-class="{'alert-success': successMessage, 'alert-danger': errorMessage}" ng-show="successMessage || errorMessage">
      {{ successMessage || errorMessage }}
    </div>
  </div>

  <script>
    angular.module('registrationApp', [])
      .controller('RegistrationController', ['$scope', '$http', function($scope, $http) {
        $scope.user = {};
        $scope.successMessage = '';
        $scope.errorMessage = '';

        $scope.register = function() {
          $http.post('register.php', $scope.user)
            .then(function(response) {
              if (response.data.success) {
                $scope.successMessage = response.data.message;
                $scope.errorMessage = '';
                $scope.clearForm();
              } else {
                $scope.errorMessage = response.data.message;
                $scope.successMessage = '';
              }
            }, function(error) {
              $scope.errorMessage = 'An error occurred. Please try again later.';
              $scope.successMessage = '';
            });
        };

        $scope.clearForm = function() {
          $scope.user = {};
          $scope.registrationForm.$setPristine();
          $scope.registrationForm.$setUntouched();
        };
      }]);
  </script>
</body>
</html>
