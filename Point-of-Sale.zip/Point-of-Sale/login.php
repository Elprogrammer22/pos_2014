<?php
require("./config/database.php");

// Check if the login form was submitted
if (isset($_POST['login'])) {
    // Basic input validation
    if (empty($_POST['a_username']) || empty($_POST['a_password'])) {
        $error = "All fields are required";
    } else {
        // Retrieve username and password from the form
        $username = mysqli_real_escape_string($conn, $_POST['a_username']);
        $password = mysqli_real_escape_string($conn, $_POST['a_password']);

        // Prepare and execute SQL statement to retrieve user data
        $sql = "SELECT * FROM pos_accnt WHERE a_username=?";
        $stmt = mysqli_stmt_init($conn);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            // Check if a user with the provided username exists
            if ($row = mysqli_fetch_assoc($result)) {
                // Verify the password
                if (password_verify($password, $row['a_password'])) {
                    // Password is correct, set session variables and redirect to dashboard
                    session_start();
                    $_SESSION['loggedin'] = true;
                    $_SESSION['username'] = $username;
                    header('Location: dashboard.php');
                    exit();
                } else {
                    // Incorrect password
                    $error = "Incorrect Password";
                }
            } else {
                // No user found with the provided username
                $error = "User not found";
            }
        } else {
            // SQL statement preparation failed
            $error = "Something went wrong";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>POS | Login</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font -->
  <link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #17a2b8, #FFA500) 100%;
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
      background-image: url('https://cdn.jsdelivr.net/gh/subtlepatterns/Free/SubtlePatterns/white_carbon.png');
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      max-width: 400px;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
      background-color: #fff;
      animation: fade-in 0.5s ease-out;
    }
    @keyframes fade-in {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    .form-control {
      border-radius: 25px;
    }
    .btn-primary {
      width: 100%;
      border-radius: 25px;
      background-color: #FFA500;
      border: none;
      transition: all 0.3s ease;
    }
    .btn-primary:hover {
      background-color: #FF8C00;
    }
  </style>
</head>

<body>
  <div class="container">
    <h4 class="text-center mt-2">Login</h4>
    <form action="./login.php" method="post">
      <div class="mb-3">
        <input type="text" class="form-control" name="a_username" placeholder="Username" required>
      </div>
      <div class="mb-3">
        <input type="password" class="form-control" name="a_password" placeholder="Password" required>
      </div>
      <button type="submit" class="btn btn-primary mb-3" name="login">Login</button>
      <p class="text-center mb-0">Don't have an account? <a href="index.php">Register Here</a></p>
    </form>
  </div>
</body>

</html>

